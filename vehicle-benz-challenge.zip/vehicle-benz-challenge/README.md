Prerequisites:
Java JRE 8, Please refer https://docs.oracle.com/javase/8/docs/technotes/guides/install/install_overview.html for installation of Java 8
Maven , Please refer
https://maven.apache.org/install.html for Installation of Maven
Docker , Please refer
https://docs.docker.com/engine/install/
Postman, Please refer
https://www.postman.com/downloads/

Steps for building application:

1.	Make sure maven is correctly Installed by running this command: mvn –version
If this returns any error, then maven is not correctly installed and the same needs to be uninstalled and installed again.
2.	Open Terminal/Command prompt, Please navigate to the folder where the project is stored, say if project is in Desktop, you can use the command :  cd Desktop to go to that particular folder. Then use the same procedure to navigate to the actual project folder.
3.	Then Please use command: mvn clean install 
4.	This will generate a jar in the project folder. Build process gets completed here.

Deployment:

1.	Make sure docker is installed by executing command docker –version
2.	Create docker image by executing the following command:
   docker build -t vehicle-benz-challenge .  (Note that full stop is also a part of the command)
3.	Use the following command to make sure the image is created properly :     docker images
4.	Once it is verified, Please run this command to deploy application to 8080 port:
   docker run -p 8080:8080 -t vehicle-benz-challenge
Deployment is completed here.

Testing:

1.	Click on post man application to open it.
2.	In the First Drop down please select POST method instead of GET and Enter the URL : http://localhost:8080/api/vehicle and Navigate to Body tab (4th tab) and check the raw check box and select JSON from drop down.
3.	Please Enter the following test case and hit send: { "vin": "W1K2062161F0046", "source": "Home", "destination": "Movie Theatre" }
The Output response would be like this:  {
    "transactionId": 2,
    "vin": "W1K2062161F0046",
    "source": "Home",
    "destination": "Movie Theatre",
    "distance": 50,
    "currentChargeLevel": 17,
    "chargingStations": [
        {
            "name": "S1",
            "distance": 10,
            "limit": 20
        },
        {
            "name": "S2",
            "distance": 25,
            "limit": 15
        }
    ],
    "chargingRequired": true
}

4.	For more test cases and extended test case output, please refer the document attached with the presentation.
