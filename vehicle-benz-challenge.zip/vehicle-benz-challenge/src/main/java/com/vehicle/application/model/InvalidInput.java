package com.vehicle.application.model;

import java.util.List;

public class InvalidInput {

	private int transactionId;
	private List<VehicleError> errors;
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public List<VehicleError> getErrors() {
		return errors;
	}
	public void setErrors(List<VehicleError> errors) {
		this.errors = errors;
	}
}
