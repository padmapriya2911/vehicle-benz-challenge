package com.vehicle.application.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.vehicle.application.model.ChargeDistanceRequest;
import com.vehicle.application.model.ChargeLevelRequest;
import com.vehicle.application.model.ChargeLevelResponse;
import com.vehicle.application.model.ChargingStationsResponse;
import com.vehicle.application.model.DistanceResponse;
import com.vehicle.application.util.VehicleConstant;

@Component
public class VehicleServiceImpl implements VehicleService{
	
	@Autowired
	RestTemplate restTemplate;

	@Override
	public ChargeLevelResponse getCurrentChargeLevel(ChargeLevelRequest chargeLevelRequest) {
		ChargeLevelResponse chargeLevelResponse=restTemplate.postForObject( VehicleConstant.chargeUrl, chargeLevelRequest, ChargeLevelResponse.class);
		return chargeLevelResponse;
	}

	@Override
	public DistanceResponse getDistanceResponse(ChargeDistanceRequest chargeDistanceRequest) {
		DistanceResponse distanceResponse=restTemplate.postForObject(VehicleConstant.chargeLevel, chargeDistanceRequest, DistanceResponse.class);
		return distanceResponse;	
	}

	@Override
	public ChargingStationsResponse getChargingStations(ChargeDistanceRequest chargeDistanceRequest) {
		ChargingStationsResponse chargingStationsResponse=restTemplate.postForObject(VehicleConstant.chargingStations, chargeDistanceRequest, ChargingStationsResponse.class);
		return chargingStationsResponse;	
	}
	

}
