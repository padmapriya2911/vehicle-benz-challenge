package com.vehicle.application.service;

import org.springframework.stereotype.Service;

import com.vehicle.application.model.ChargeDistanceRequest;
import com.vehicle.application.model.ChargeLevelRequest;
import com.vehicle.application.model.ChargeLevelResponse;
import com.vehicle.application.model.ChargingStationsResponse;
import com.vehicle.application.model.DistanceResponse;


@Service
public interface VehicleService {
    public ChargeLevelResponse getCurrentChargeLevel(ChargeLevelRequest chargeLevelRequest);
    public DistanceResponse getDistanceResponse(ChargeDistanceRequest chargeDistanceRequest);
    public ChargingStationsResponse getChargingStations(ChargeDistanceRequest chargeDistanceRequest);
}