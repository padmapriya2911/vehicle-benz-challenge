package com.vehicle.application.model;

import java.util.List;

public class ChargingStationsResponse {
  private String source;
  private String destination;
  private List<ChargingStations> chargingStations;
  private String error;
public String getSource() {
	return source;
}
public void setSource(String source) {
	this.source = source;
}
public String getDestination() {
	return destination;
}
public void setDestination(String destination) {
	this.destination = destination;
}
public List<ChargingStations> getChargingStations() {
	return chargingStations;
}
public void setChargingStations(List<ChargingStations> chargingStations) {
	this.chargingStations = chargingStations;
}
public String getError() {
	return error;
}
public void setError(String error) {
	this.error = error;
}
}
