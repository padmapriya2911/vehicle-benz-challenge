package com.vehicle.application.util;

public class VehicleConstant {

	public static final String errorDescription="Unable to reach the destination with the current fuel level";
	public static final int errorCode=8888;
	public static final int errorCodeInvalid=9999;
	public static final String errorDescriptionInvalid="Technical Exception";
	public static final String chargeUrl="https://restmock.techgig.com/merc/charge_level";
	public static final String chargeLevel="https://restmock.techgig.com/merc/distance";
	public static final String chargingStations="https://restmock.techgig.com/merc/charging_stations";
	
}
