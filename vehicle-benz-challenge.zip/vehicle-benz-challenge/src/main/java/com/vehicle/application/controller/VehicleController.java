package com.vehicle.application.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vehicle.application.model.InvalidInput;
import com.vehicle.application.model.VehicleError;
import com.vehicle.application.model.VehicleInput;
import com.vehicle.application.model.VehicleOutput;
import com.vehicle.application.util.VehicleConstant;
import com.vehicle.application.util.VehicleUtil;

@RestController
@RequestMapping("/api")
public class VehicleController {

	@Autowired
	VehicleUtil vehicleUtil;

	@PostMapping("/vehicle")
	public ResponseEntity<?> automonousVehicles(@RequestBody VehicleInput input) {
		try {
			if(vehicleUtil.isValidInput(input)) {
			VehicleOutput vehicleOutput=vehicleUtil.vehicleProcessor(input);
			return new ResponseEntity<>(vehicleOutput, HttpStatus.OK);
			}else {
				InvalidInput invalidInput=new InvalidInput();
				invalidInput.setTransactionId(vehicleUtil.getRandomUniqueInteger());
				List<VehicleError> errorList=new ArrayList<>();
				VehicleError error=new VehicleError();
				error.setDescription(VehicleConstant.errorDescriptionInvalid);
				error.setId(VehicleConstant.errorCodeInvalid);
				errorList.add(error);
				invalidInput.setErrors(errorList);
				return new ResponseEntity<>(invalidInput, HttpStatus.OK);
			}
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		//To do:
		//
		// junits, presentation, complete documentation,read me file, upload it in github
		//Reconsolidate all calls, remove duplicates 
		//done:
		//docker,
		//code clean up but logic is done and dusted, addition of all result and POJO transformation.
		//Change chargingRequired to isChargingRequired
		//
		
	}
}
