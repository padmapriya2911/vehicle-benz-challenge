package com.vehicle.application.model;

import java.util.List;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class VehicleOutput {

	private int transactionId;
	private String vin;
	private String source;
	private String destination;
	private int distance;
	private int currentChargeLevel;
	private boolean isChargingRequired;
	private List<ChargingStations>chargingStations;
	private List<VehicleError> errrorList;
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public String getVin() {
		return vin;
	}
	public void setVin(String vin) {
		this.vin = vin;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public int getDistance() {
		return distance;
	}
	public void setDistance(int distance) {
		this.distance = distance;
	}
	public int getCurrentChargeLevel() {
		return currentChargeLevel;
	}
	public void setCurrentChargeLevel(int currentChargeLevel) {
		this.currentChargeLevel = currentChargeLevel;
	}
	public boolean isChargingRequired() {
		return isChargingRequired;
	}
	public void setisChargingRequired(boolean isChargingRequired) {
		this.isChargingRequired = isChargingRequired;
	}
	public List<ChargingStations> getChargingStations() {
		return chargingStations;
	}
	public void setChargingStations(List<ChargingStations> chargingStations) {
		this.chargingStations = chargingStations;
	}
	public List<VehicleError> getErrrorList() {
		return errrorList;
	}
	public void setErrrorList(List<VehicleError> errrorList) {
		this.errrorList = errrorList;
	}
	
}
