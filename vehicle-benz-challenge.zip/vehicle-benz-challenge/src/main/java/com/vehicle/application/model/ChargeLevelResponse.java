package com.vehicle.application.model;

public class ChargeLevelResponse  {
private String vin;
private int currentChargeLevel;
private String errors;
public String getVin() {
	return vin;
}
public void setVin(String vin) {
	this.vin = vin;
}

public String getErrors() {
	return errors;
}
public void setErrors(String errors) {
	this.errors = errors;
}
public int getCurrentChargeLevel() {
	return currentChargeLevel;
}
public void setCurrentChargeLevel(int currentChargeLevel) {
	this.currentChargeLevel = currentChargeLevel;
}
}
