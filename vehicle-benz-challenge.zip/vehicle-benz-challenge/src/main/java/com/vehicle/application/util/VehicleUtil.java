package com.vehicle.application.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.vehicle.application.model.ChargeDistanceRequest;
import com.vehicle.application.model.ChargeLevelRequest;
import com.vehicle.application.model.ChargeLevelResponse;
import com.vehicle.application.model.ChargingStations;
import com.vehicle.application.model.ChargingStationsResponse;
import com.vehicle.application.model.DistanceResponse;
import com.vehicle.application.model.VehicleError;
import com.vehicle.application.model.VehicleInput;
import com.vehicle.application.model.VehicleOutput;
import com.vehicle.application.service.VehicleServiceImpl;

@Component
public class VehicleUtil{
	

	
	@Autowired
	VehicleServiceImpl vehicleServiceImpl;
	
	
	//Instatiating all Request and Response Classes
	ChargeLevelRequest chargeLevelRequest=new ChargeLevelRequest();
	ChargeDistanceRequest chargeDistanceRequest = new ChargeDistanceRequest();
	DistanceResponse distanceResponse=new DistanceResponse();
	VehicleOutput vehicleOutput=new VehicleOutput();
	
	public VehicleOutput vehicleProcessor(VehicleInput input) {
		//Setting Mandatory Values from External Services
		ChargeLevelResponse chargeLevelResponse = setEssentialValues(input);
	    int currentChargeLevel=chargeLevelResponse.getCurrentChargeLevel();
	    int currentDistance=distanceResponse.getDistance();
		fillCommonFields(input, currentChargeLevel, currentDistance);
	    if(currentChargeLevel-currentDistance>0) {
	    	return setNoChargingResult(false);
	    }else {
	    	return setChargingResult(input,currentChargeLevel, currentDistance,true); 
	    	
	    }
	}


	private void fillCommonFields(VehicleInput input, int currentChargeLevel, int currentDistance) {
		vehicleOutput.setTransactionId(getRandomUniqueInteger());
		vehicleOutput.setVin(input.getVin());
		vehicleOutput.setSource(input.getSource());
		vehicleOutput.setDestination(input.getDestination());
		vehicleOutput.setDistance(currentDistance);
		vehicleOutput.setCurrentChargeLevel(currentChargeLevel);
	}


	private VehicleOutput setChargingResult(VehicleInput input,int currentChargeLevel, int currentDistance,boolean isChargingRequ) {
		int chargeDifference;
		List<ChargingStations> resultantStations=new ArrayList<ChargingStations>();
		ChargingStationsResponse chargeStationResponse=vehicleServiceImpl.getChargingStations(chargeDistanceRequest);
		chargeDifference=currentDistance-currentChargeLevel; 	
		if(chargeStationResponse.getError()!=null) {
			 return erroredOutput(isChargingRequ);
		}
		for(ChargingStations chargingStations:chargeStationResponse.getChargingStations()) {
		   currentChargeLevel=currentChargeLevel-chargingStations.getDistance();
		   if(currentChargeLevel>0) {
			   if(currentChargeLevel+chargingStations.getLimit()==chargeDifference || currentChargeLevel+chargingStations.getLimit()>chargeDifference) {
					resultantStations.add(chargingStations);
					break;
				}else {
					resultantStations.add(chargingStations);
					currentChargeLevel=currentChargeLevel+chargingStations.getLimit();;
					chargeDifference=currentChargeLevel-chargeDifference;
				}
		   }else {
			   return erroredOutput(isChargingRequ);
		   }
				
		}
		
		return standardOutput(isChargingRequ,resultantStations);
		
	}

	private VehicleOutput standardOutput(boolean isChargingRequ, List<ChargingStations> resultantStations) {
		   vehicleOutput.setisChargingRequired(isChargingRequ);
		   vehicleOutput.setChargingStations(resultantStations);
		   return vehicleOutput;
	}

	private VehicleOutput erroredOutput(boolean isChargingRequ) {
		   vehicleOutput.setisChargingRequired(isChargingRequ);
		   VehicleError vehicleError=new VehicleError();
		   List<VehicleError> errorList=new ArrayList<VehicleError>();
		   vehicleError.setDescription(VehicleConstant.errorDescription);
		   vehicleError.setId(VehicleConstant.errorCode);
		   errorList.add(vehicleError);
		   vehicleOutput.setErrrorList(errorList);
		   return vehicleOutput;
	}

	private VehicleOutput setNoChargingResult(boolean isChargeReq) {	
		vehicleOutput.setisChargingRequired(isChargeReq);
		return vehicleOutput;
	}

	public int getRandomUniqueInteger() {
		List<Integer> numbers = new ArrayList<Integer>();
		for(int i = 0; i < 40; i++)
		{
		numbers.add(i+1);
		}
		Collections.shuffle(numbers);
		return numbers.get(numbers.size()-3);
	}

	private ChargeLevelResponse setEssentialValues(VehicleInput input) {
		chargeLevelRequest.setVin(input.getVin());
		chargeDistanceRequest.setDestination(input.getDestination());
		chargeDistanceRequest.setSource(input.getSource());
		distanceResponse=vehicleServiceImpl.getDistanceResponse(chargeDistanceRequest);
	    ChargeLevelResponse chargeLevelResponse=vehicleServiceImpl.getCurrentChargeLevel(chargeLevelRequest);
		return chargeLevelResponse;
	}
	
	public boolean isValidInput(VehicleInput vehicleInput) {
		chargeDistanceRequest.setDestination(vehicleInput.getDestination());
		chargeDistanceRequest.setSource(vehicleInput.getSource());
		distanceResponse=vehicleServiceImpl.getDistanceResponse(chargeDistanceRequest);
		if(distanceResponse.getError()!=null && distanceResponse.getSource()==null && distanceResponse.getDestination()==null) {
			return false;
		}
		return true;
	}
	

}
