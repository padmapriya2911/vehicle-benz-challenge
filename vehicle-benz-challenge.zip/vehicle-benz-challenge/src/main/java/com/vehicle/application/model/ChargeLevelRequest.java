package com.vehicle.application.model;

public class ChargeLevelRequest {
private String vin;

public String getVin() {
	return vin;
}

public void setVin(String vin) {
	this.vin = vin;
}

	
}
