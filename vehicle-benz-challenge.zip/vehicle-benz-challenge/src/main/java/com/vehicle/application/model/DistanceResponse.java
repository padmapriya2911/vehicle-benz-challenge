package com.vehicle.application.model;

public class DistanceResponse {
		  private String source;
		  private String destination;
		  private String error;
		  private int distance;
		 
		public String getSource() {
			return source;
		}
		public void setSource(String source) {
			this.source = source;
		}
		public String getDestination() {
			return destination;
		}
		public void setDestination(String destination) {
			this.destination = destination;
		}
		public int getDistance() {
			return distance;
		}
		public void setDistance(int distance) {
			this.distance = distance;
		}
		public String getError() {
			return error;
		}
		public void setErrors(String error) {
			this.error = error;
		}
		  
		}


